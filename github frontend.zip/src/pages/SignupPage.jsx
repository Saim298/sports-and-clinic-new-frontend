import React from 'react'
import Signup from '../component/Signup'

const SignupPage = () => {
  return (
    <div><Signup/></div>
  )
}

export default SignupPage