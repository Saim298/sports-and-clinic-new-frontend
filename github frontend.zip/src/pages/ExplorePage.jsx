import React from 'react'
import Explore from '../component/Explore'

const ExplorePage = () => {
  return (
    <div><Explore/></div>
  )
}

export default ExplorePage