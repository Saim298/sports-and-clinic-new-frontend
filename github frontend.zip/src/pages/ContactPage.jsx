import React from 'react'
import Contact from '../component/Contact'

const ContactPage = () => {
  return (
    <div><Contact/></div>
  )
}

export default ContactPage