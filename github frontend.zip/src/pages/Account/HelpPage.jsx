import React from 'react'
import Help from '../../component/Account/Help'

const HelpPage = () => {
  return (
    <div><Help/></div>
  )
}

export default HelpPage