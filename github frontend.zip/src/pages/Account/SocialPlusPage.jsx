import React from 'react'
import SocialPlus from '../../component/Account/SocialPlus'

const SocialPlusPage = () => {
  return (
    <div><SocialPlus/></div>
  )
}

export default SocialPlusPage