import React from 'react'
import Profile from '../../component/Account/Profile'

const ProfilePage = () => {
  return (
    <div><Profile/></div>
  )
}

export default ProfilePage