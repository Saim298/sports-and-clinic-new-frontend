import React from 'react'
import Overview from '../../component/Account/Overview'

const OverviewPage = () => {
  return (
    <div><Overview/></div>
  )
}

export default OverviewPage