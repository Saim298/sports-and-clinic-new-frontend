import React from 'react'
import Home from '../component/Home'

const HomePage = () => {
  return (
    <div><Home/></div>
  )
}

export default HomePage