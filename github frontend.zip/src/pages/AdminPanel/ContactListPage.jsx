import React from 'react'
import ContactList from '../../component/AdminPanel/ContactList'

const ContactListPage = () => {
  return (
    <div><ContactList/></div>
  )
}

export default ContactListPage