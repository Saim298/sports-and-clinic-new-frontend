import React from 'react'
import UserPlans from '../../component/AdminPanel/UserPlans'

const UserPlansPage = () => {
  return (
    <div><UserPlans/></div>
  )
}

export default UserPlansPage