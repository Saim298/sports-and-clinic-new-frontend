import React from 'react'
import InvoiceTemplate from '../../component/AdminPanel/InvoiceTemplate'

const InvoiceTemplatePage = () => {
  return (
    <div><InvoiceTemplate/></div>
  )
}

export default InvoiceTemplatePage