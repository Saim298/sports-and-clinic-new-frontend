import React from 'react'
import UsersList from '../../component/AdminPanel/UsersList'

const UsersListPage = () => {
  return (
    <div><UsersList/></div>
  )
}

export default UsersListPage