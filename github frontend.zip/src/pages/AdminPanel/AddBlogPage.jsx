import React from 'react'
import AddBlog from '../../component/AdminPanel/Blogs/AddBlog'

const AddBlogPage = () => {
  return (
    <div><AddBlog/></div>
  )
}

export default AddBlogPage