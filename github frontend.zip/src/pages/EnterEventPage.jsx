import React from 'react'
import EnterEvent from '../component/EnterEvent'

const EnterEventPage = () => {
  return (
    <div><EnterEvent/></div>
  )
}

export default EnterEventPage