import React from 'react'
import Faqs from '../component/Faqs'

const FaqsPage = () => {
  return (
    <div><Faqs/></div>
  )
}

export default FaqsPage