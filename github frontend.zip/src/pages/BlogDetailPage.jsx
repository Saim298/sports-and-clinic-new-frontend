import React from 'react'
import BlogDetail from '../component/Blog/BlogDetail'

const BlogDetailPage = () => {
  return (
    <div><BlogDetail/></div>
  )
}

export default BlogDetailPage