import React from 'react'
import ProfileAccount2 from '../../component/Account2/ProfileAccount2'

const ProfileAccount2Page = () => {
  return (
    <div><ProfileAccount2/></div>
  )
}

export default ProfileAccount2Page