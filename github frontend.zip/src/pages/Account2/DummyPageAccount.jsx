import React from 'react'
import DummyPage from '../../component/Account2/DummyPage'

const DummyPageAccount = () => {
  return (
    <div><DummyPage/></div>
  )
}

export default DummyPageAccount