import React from 'react'
import Account2 from '../../component/Account2'

const MainPage = () => {
  return (
    <div><Account2/></div>
  )
}

export default MainPage